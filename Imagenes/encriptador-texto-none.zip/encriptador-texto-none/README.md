# encriptador-texto
Encriptador / Desencriptador  de Texto con JavaScript
